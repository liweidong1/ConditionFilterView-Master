//
//  QZSortCell.h
//  circle_iphone
//
//  Created by MrYu on 16/8/2.
//  Copyright © 2016年 ctquan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QZSortCell : UITableViewCell

@property (nonatomic,strong) UIImageView *markView;

+ (instancetype)sortCell;

@end
