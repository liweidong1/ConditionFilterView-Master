//
//  MMCombinationFitlerView.h
//  MMComboBoxDemo
//
//  Created by wyy on 2016/12/8.
//  Copyright © 2016年 wyy. All rights reserved.
//

#import "MMBasePopupView.h"
#import "MMCombinationItem.h"
@interface MMCombinationFitlerView : MMBasePopupView
@property (nonatomic, strong) MMCombinationItem *item;
@end

